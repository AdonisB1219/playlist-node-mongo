# playlist-node-mongo
This is an api that lets save playlists of songs according to their genre, using Mongodb
